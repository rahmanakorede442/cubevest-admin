export { default } from './Minimal';
