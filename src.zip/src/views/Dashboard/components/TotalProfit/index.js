export { default } from './TotalProfit';
